document.addEventListener('DOMContentLoaded', function() {
    const btnAbsen = document.getElementById('btn-absen');
    if(btnAbsen) {
        btnAbsen.addEventListener('click', function() {
            btnAbsen.disabled = true;
            fetch('/api/absensi', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ lokasi_cabang: 'Pusat (Otomatis)' })
            })
            .then(res => res.json())
            .then(data => {
                const statusEl = document.getElementById('absen-status');
                if(data.status === 'success') {
                    statusEl.style.color = 'green';
                    statusEl.innerText = 'Kehadiran berhasil dicatat!';
                    if(userRole === 'Admin') loadAdminData();
                } else {
                    statusEl.style.color = 'red';
                    statusEl.innerText = 'Gagal: ' + data.message;
                    btnAbsen.disabled = false;
                }
            })
            .catch(err => {
                console.error(err);
                btnAbsen.disabled = false;
            });
        });
    }

    function loadAdminData() {
        if(userRole !== 'Admin') return;
        
        fetch('/api/absensi')
            .then(response => response.json())
            .then(data => {
                if(data.status === 'error') return;
                
                const tbody = document.querySelector('#tabel-absensi tbody');
                tbody.innerHTML = ''; 
                let hadirCount = 0;
                let cabangCount = {};

                data.forEach(row => {
                    if(!row.NIK) return;
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${row.NIK || '-'}</td>
                        <td>${row.Nama || '-'}</td>
                        <td>${row.Waktu || '-'}</td>
                        <td>${row.Lokasi_Cabang || '-'}</td>
                        <td>${row.Status || '-'}</td>
                    `;
                    tbody.appendChild(tr);
                    if(row.Status === 'Hadir') hadirCount++;
                    const cabang = row.Lokasi_Cabang || 'Unknown';
                    cabangCount[cabang] = (cabangCount[cabang] || 0) + 1;
                });

                document.getElementById('total-hadir').innerText = hadirCount;
                renderChart(cabangCount);
            });
    }

    let kehadiranChart = null;
    function renderChart(cabangCount) {
        const ctx = document.getElementById('kehadiranChart').getContext('2d');
        if (kehadiranChart) kehadiranChart.destroy();
        kehadiranChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(cabangCount),
                datasets: [{
                    label: 'Jumlah Kehadiran per Cabang',
                    data: Object.values(cabangCount),
                    backgroundColor: '#0056b3'
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
        });
    }

    loadAdminData();
});
