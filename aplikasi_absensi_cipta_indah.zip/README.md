# Aplikasi Absensi Pegawai - CB. CIPTA INDAH LAKSANA

Aplikasi Web Absensi berbasis Python (Flask) dengan database Google Sheets API.
