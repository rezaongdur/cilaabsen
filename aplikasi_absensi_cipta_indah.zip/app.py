from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'kunci_rahasia_cb_cipta_indah_laksana'

scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds_path = 'credentials.json'

def get_sheet():
    if not os.path.exists(creds_path):
        return None
    try:
        creds = ServiceAccountCredentials.from_json_keyfile_name(creds_path, scope)
        client = gspread.authorize(creds)
        return client.open("DB_Absensi_Pegawai")
    except Exception as e:
        print(f"Error Google Sheets: {e}")
        return None

@app.route('/')
def index():
    if 'nik' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    nik_input = request.form.get('nik')
    sheet_db = get_sheet()
    
    if not sheet_db:
        return render_template('login.html', error="Sistem belum terhubung ke Google Sheets. Periksa credentials.json")
        
    sheet_pegawai = sheet_db.worksheet("Pegawai")
    pegawai_records = sheet_pegawai.get_all_records()
    
    for pegawai in pegawai_records:
        if str(pegawai['NIK']) == str(nik_input):
            session['nik'] = pegawai['NIK']
            session['nama'] = pegawai['Nama']
            session['role'] = pegawai['Role']
            return redirect(url_for('dashboard'))
            
    return render_template('login.html', error="NIK tidak ditemukan atau tidak valid.")

@app.route('/dashboard')
def dashboard():
    if 'nik' not in session:
        return redirect(url_for('index'))
    return render_template('dashboard.html', nama=session['nama'], role=session['role'])

@app.route('/api/absensi', methods=['GET', 'POST'])
def api_absensi():
    sheet_db = get_sheet()
    if not sheet_db:
        return jsonify({"status": "error", "message": "Database error"}), 500
        
    sheet_absensi = sheet_db.worksheet("Absensi")
    
    if request.method == 'POST':
        data = request.json
        waktu_sekarang = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sheet_absensi.append_row([session.get('nik'), session.get('nama'), waktu_sekarang, data.get('lokasi_cabang', 'Pusat'), "Hadir"])
        return jsonify({"status": "success", "message": "Absensi berhasil dicatat."}), 201
        
    elif request.method == 'GET':
        data_absensi = sheet_absensi.get_all_records()
        return jsonify(data_absensi), 200

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
