import unittest
from app import app

class AbsensiAppTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_halaman_login_dimuat(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)

    def test_akses_dashboard_tanpa_login(self):
        response = self.app.get('/dashboard', follow_redirects=True)
        self.assertIn(b'Masuk', response.data)

if __name__ == '__main__':
    unittest.main()
